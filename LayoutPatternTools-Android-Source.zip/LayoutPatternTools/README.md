# Layout Pattern Tools (Geode / Android)

This is a **starter project**, not a compiled or verified `.geode` release.

## Current scope
- Adds a large touch-oriented `PATTERNS` button to the Geometry Dash editor UI.
- The button currently opens an informational popup.
- Automatic pattern placement is intentionally not implemented in this starter because the editor-object API must be verified against the exact Geode SDK and Geometry Dash Android build before safely adding objects to a user's level.

## Target
- Android 64-bit (`Android64`), appropriate for 64-bit ARM devices.
- `mod.json` currently targets Geometry Dash Android `2.2081` and Geode `v5.11.1` (the latest release visible in the official releases page at preparation time). Confirm these match the versions installed on the phone before installation.

## Build automatically
1. Create a GitHub repository and upload all files in this folder.
2. In GitHub, open **Actions** and run **Build Geode mod for Android** (or push to `main`).
3. If the workflow succeeds, open the workflow run and download the `LayoutPatternTools-Android64` artifact.
4. Install the resulting `.geode` through Geode on Android.

The workflow uses the official `geode-sdk/build-geode-mod` action with the latest available SDK/CLI at build time. The exact `mod.json` target versions still need to match the Geode/GD version installed on the phone.

## Important limitations
- This environment did not run the Android NDK/Geode build, so compilation is **not verified**.
- The first build may fail if the declared Geode SDK/GD target versions are no longer current or if the current SDK changed the `EditorUI` hook API. Resolve those errors in the GitHub Actions log before installing.
- The actual pattern generator (placing spikes/orbs/pads/portals) is not implemented yet; this package is a starter UI scaffold and must not be described as a finished pattern-generation mod.
