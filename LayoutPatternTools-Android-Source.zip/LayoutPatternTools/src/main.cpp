#include <Geode/Geode.hpp>
#include <Geode/modify/EditorUI.hpp>

using namespace geode::prelude;

// First version: a small, touch-friendly editor button that opens pattern presets.
// Presets place ordinary Geometry Dash objects in the current editor level.
class $modify(LayoutPatternEditorUI, EditorUI) {
    bool init(LevelEditorLayer* editorLayer) {
        if (!EditorUI::init(editorLayer)) return false;

        auto menu = CCMenu::create();
        if (!menu) return true;
        menu->setID("layout-pattern-tools-menu");
        menu->setPosition({0, 0});

        auto label = CCLabelBMFont::create("PATTERNS", "bigFont.fnt");
        if (!label) return true;
        label->setScale(0.42f);
        auto button = CCMenuItemSpriteExtra::create(
            label,
            this,
            menu_selector(LayoutPatternEditorUI::onOpenPatternMenu)
        );
        if (!button) return true;
        button->setID("layout-pattern-tools-button");
        button->setContentSize({76.f, 30.f});
        button->setPosition({48.f, 28.f});
        menu->addChild(button);
        this->addChild(menu, 1000);
        return true;
    }

    void onOpenPatternMenu(CCObject*) {
        FLAlertLayer::create(
            "Layout Pattern Tools",
            "Choose a pattern preset in the next version.\n\n"
            "This starter build adds the editor button only; automatic object placement "
            "is not enabled until the target Geode/GD bindings are compiled and tested.",
            "OK"
        )->show();
    }
};
